var i=(n,f)=>()=>(f||n((f={exports:{}}).exports,f),f.exports);var u=i((s,c)=>{const t=(n,f)=>function(a){const l=e(a.target,n,this);l!==null&&f.call(l,a)};c.exports=t;const e=(n,f,r)=>n===r?null:n.matches(f)?n:n.parentNode?e(n.parentNode,f,r):null});export default u();

//# sourceMappingURL=delegate.js.map
