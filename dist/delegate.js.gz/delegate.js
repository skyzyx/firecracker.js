var l=(e,r)=>()=>(r||e((r={exports:{}}).exports,r),r.exports);var $=l((b,f)=>{function o(e){Object.defineProperty(e,"__esModule",{value:!0,configurable:!0})}function c(e,r,n,t){Object.defineProperty(e,r,{get:n,set:t,enumerable:!0,configurable:!0})}o(f.exports);c(f.exports,"default",()=>i);const d=(e,r)=>function(t){const a=u(t.target,e,this);a!==null&&r.call(a,t)};var i=d;const u=(e,r,n)=>e===n?null:e.matches(r)?e:e.parentNode&&e.parentNode!==document?u(e.parentNode,r,n):null});export default $();

//# sourceMappingURL=delegate.js.map
