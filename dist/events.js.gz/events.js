var s=(n,c)=>()=>(c||n((c={exports:{}}).exports,c),c.exports);var u=s(($,l)=>{const t=(n,c)=>function(d){const e=i(d.target,n,this);e!==null&&c.call(e,d)};l.exports=t;const i=(n,c,r)=>n===r?null:n.matches(c)?n:n.parentNode?i(n.parentNode,c,r):null});export default u();

//# sourceMappingURL=events.js.map
